import { forwardRef, useState } from 'react'
import { motion } from 'framer-motion'
import { ProjectShorts } from './ProjectShorts.jsx'
import { ProjectLinks } from './ProjectLinks.jsx'
import { Lightbox } from './Lightbox.jsx'
import { ImageIcon } from './ChipIcons.jsx'

// Each element enters from a different direction, staggered, cinematic
// but not exaggerated. Title slides from the left, the tablet/video
// slides in from the right, body copy rises from below.
const fromLeft = {
  hidden: { opacity: 0, x: -36 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.65, ease: [0.22, 1, 0.36, 1] } },
}
const fromRight = {
  hidden: { opacity: 0, x: 36 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.65, ease: [0.22, 1, 0.36, 1], delay: 0.08 } },
}
const fromBelow = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1], delay: 0.18 } },
}

const galleryVariants = {
  hidden: { opacity: 0, scale: 0.97, y: 16 },
  visible: (i) => ({
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1], delay: 0.08 * i },
  }),
}

export const ProjectSection = forwardRef(function ProjectSection(
  { project, index, total, isActive },
  ref
) {
  const hasVideo = Boolean(project.mainVideo)
  const [lightboxContent, setLightboxContent] = useState(null)

  return (
    <section
      ref={ref}
      id={project.id}
      className={`project-section ${isActive ? 'project-section-active' : ''}`}
      data-index={index}
      // colour overlay: low-opacity tinted layer over the video bg
      style={{ '--project-color': project.color, '--project-glow': project.glowColor }}
    >
      {/* per-project colour scrim, sits above the global video bg scrim */}
      <div className="project-color-scrim" aria-hidden="true" />

      <div className="project-content">
        <div className="project-text-block">
          <motion.div
            className="project-title-block"
            initial="hidden"
            animate={isActive ? 'visible' : 'hidden'}
            variants={fromLeft}
          >
            {project.badge && <p className="project-meta mono">{project.badge}</p>}
            <h2 className="project-title">{project.title}</h2>
          </motion.div>

          <motion.div
            className="project-body-block"
            initial="hidden"
            animate={isActive ? 'visible' : 'hidden'}
            variants={fromBelow}
          >
            {project.description && (
              <p
                className="project-description"
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{ __html: project.description }}
              />
            )}

            {project.creditsHTML && (
              <div
                className="project-credits"
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{ __html: project.creditsHTML }}
              />
            )}

            <ProjectLinks links={project.links} />

            {project.embed && (
              <div
                className="project-embed"
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{ __html: project.embed }}
              />
            )}
          </motion.div>
        </div>

        {hasVideo && (
          <motion.div
            className="project-shorts-wrap"
            initial="hidden"
            animate={isActive ? 'visible' : 'hidden'}
            variants={fromRight}
          >
            <ProjectShorts
              mainVideo={project.mainVideo}
              incidental={project.incidentalVideos}
              projectIsActive={isActive}
            />

            {project.gallery?.length > 0 && (
              <div className="project-gallery">
                {project.gallery.map((src, i) => (
                  <motion.button
                    key={src}
                    type="button"
                    className="chip-pill"
                    custom={i}
                    initial="hidden"
                    animate={isActive ? 'visible' : 'hidden'}
                    variants={galleryVariants}
                    onClick={() => setLightboxContent({ type: 'image', src, alt: '' })}
                    aria-label={`View image ${i + 1}`}
                  >
                    <img className="chip-pill-thumb" src={src} alt="" loading="lazy" />
                    <ImageIcon className="chip-pill-platform" />
                  </motion.button>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </div>

      <Lightbox content={lightboxContent} onClose={() => setLightboxContent(null)} />
    </section>
  )
})
