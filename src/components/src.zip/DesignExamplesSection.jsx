import { forwardRef, useState } from 'react'

// One-off scroll section for the "Print & Editorial Design" project
// (rawProjectData id 18). Doesn't go through ProjectSection's
// title/tablet/video layout since there's no video content here — this
// recreates the source PDF's own composition instead (eyebrow + heading
// stack, category-grouped image rows). Reuses App.css's
// .modal-image-lightbox-* classes (including the prev/next nav) so the
// lightbox behavior matches the rest of the site exactly.
//
// Accepts the same (project, index, total, isActive) + ref contract
// App.jsx passes to every ProjectSection, so the intersection observer
// and Lenis section-index tracking in App.jsx work identically for this
// section — it's a drop-in swap, not a special path through App.jsx's
// scroll machinery. NOTE: assumes `project.id` is the raw projects{}
// key ('18') as a string, matching how ProjectGrid/App.jsx use
// project.id elsewhere (tile-${project.id}, getElementById, ?project=
// deep links) — flag this if projects.js derives id differently.

const GROUPS = [
  {
    label: 'Recurring magazine layout design',
    items: [
      {
        title: 'Custody with Culture',
        ratio: 1.44,
        grid: 'images/gallery/print-editorial/grid/custody_with_culture.webp',
        full: 'images/gallery/print-editorial/full/custody_with_culture.jpg',
      },
      {
        title: 'Ahakoa He Iti He Pounamu',
        ratio: 1.489,
        grid: 'images/gallery/print-editorial/grid/ahakoa_he_iti.webp',
        full: 'images/gallery/print-editorial/full/ahakoa_he_iti.jpg',
      },
    ],
  },
  {
    label: 'Musical theatre covers and layouts',
    items: [
      {
        title: 'Jesus Christ Superstar',
        ratio: 0.702,
        grid: 'images/gallery/print-editorial/grid/jesus_christ_superstar.webp',
        full: 'images/gallery/print-editorial/full/jesus_christ_superstar.jpg',
      },
      {
        title: 'Cats',
        ratio: 0.684,
        grid: 'images/gallery/print-editorial/grid/cats.webp',
        full: 'images/gallery/print-editorial/full/cats.jpg',
      },
      {
        title: 'Miss Saigon',
        ratio: 0.715,
        grid: 'images/gallery/print-editorial/grid/miss_saigon.webp',
        full: 'images/gallery/print-editorial/full/miss_saigon.jpg',
      },
      {
        title: 'The Producers',
        ratio: 0.727,
        grid: 'images/gallery/print-editorial/grid/the_producers.webp',
        full: 'images/gallery/print-editorial/full/the_producers.jpg',
      },
      {
        title: 'Cast in Order of Appearance',
        ratio: 1.379,
        grid: 'images/gallery/print-editorial/grid/cast_musical_numbers.webp',
        full: 'images/gallery/print-editorial/full/cast_musical_numbers.jpg',
      },
    ],
  },
  {
    label: 'Cover + layout design',
    items: [
      {
        title: 'Annual Plan 2005/06',
        ratio: 0.707,
        grid: 'images/gallery/print-editorial/grid/annual_plan_cover.webp',
        full: 'images/gallery/print-editorial/full/annual_plan_cover.jpg',
      },
      {
        title: 'Annual Plan',
        ratio: 0.743,
        grid: 'images/gallery/print-editorial/grid/lake_mountain_cover.webp',
        full: 'images/gallery/print-editorial/full/lake_mountain_cover.jpg',
      },
      {
        title: 'Funding Impact Statement',
        ratio: 1.498,
        grid: 'images/gallery/print-editorial/grid/funding_impact.webp',
        full: 'images/gallery/print-editorial/full/funding_impact.jpg',
      },
      {
        title: 'They Continue in Faith',
        ratio: 1.71,
        grid: 'images/gallery/print-editorial/grid/they_continue_in_faith.webp',
        full: 'images/gallery/print-editorial/full/they_continue_in_faith.jpg',
      },
    ],
  },
  {
    label: '',
    items: [
      {
        title: 'Annual Plan 2005/06',
        ratio: 0.707,
        grid: 'images/gallery/print-editorial/grid/annual_plan_cover.webp',
        full: 'images/gallery/print-editorial/full/annual_plan_cover.jpg',
      },
      {
        title: 'Annual Plan',
        ratio: 0.743,
        grid: 'images/gallery/print-editorial/grid/lake_mountain_cover.webp',
        full: 'images/gallery/print-editorial/full/lake_mountain_cover.jpg',
      },
      {
        title: 'Funding Impact Statement',
        ratio: 1.498,
        grid: 'images/gallery/print-editorial/grid/funding_impact.webp',
        full: 'images/gallery/print-editorial/full/funding_impact.jpg',
      },
      {
        title: 'They Continue in Faith',
        ratio: 1.71,
        grid: 'images/gallery/print-editorial/grid/they_continue_in_faith.webp',
        full: 'images/gallery/print-editorial/full/they_continue_in_faith.jpg',
      },
    ],
  },
]

// Flattened, ordered list of every image across all groups — this is
// what the lightbox navigates prev/next through, independent of which
// group a given image is displayed under.
const ALL_IMAGES = GROUPS.flatMap((g) => g.items)

export const DesignExamplesSection = forwardRef(function DesignExamplesSection(
  { project },
  ref
) {
  const [lightboxIndex, setLightboxIndex] = useState(null)

  function lightboxNext() {
    setLightboxIndex((i) => (i + 1) % ALL_IMAGES.length)
  }
  function lightboxPrev() {
    setLightboxIndex((i) => (i - 1 + ALL_IMAGES.length) % ALL_IMAGES.length)
  }

  return (
    <section className="project-section design-grid-section" id={project.id} ref={ref}>
      <div className="design-grid-content">
        <div>
          <div className="design-grid-eyebrow mono">Design examples</div>
          <div className="design-grid-headings">
            <span>Covers</span>
            <span>Typography</span>
            <span>Layout design</span>
          </div>
        </div>

        <div className="design-grid-groups">
          {GROUPS.map((group) => (
            <div key={group.label}>
              <div className="design-grid-group-label mono">{group.label}</div>
              <div className="design-grid-row">
                {group.items.map((item) => {
                  const globalIndex = ALL_IMAGES.indexOf(item)
                  return (
                    <button
                      key={item.title}
                      type="button"
                      className="design-grid-item"
                      style={{ width: `${11.5 * item.ratio}rem` }}
                      onClick={() => setLightboxIndex(globalIndex)}
                    >
                      <img src={item.grid} alt={item.title} loading="lazy" />
                    </button>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {lightboxIndex !== null && (
        <div className="modal-image-lightbox" onClick={() => setLightboxIndex(null)}>
          <span className="modal-image-lightbox-close" onClick={() => setLightboxIndex(null)}>&times;</span>

          <div className="modal-image-lightbox-counter mono">
            {lightboxIndex + 1} / {ALL_IMAGES.length}
          </div>

          <button
            type="button"
            className="modal-image-lightbox-nav modal-image-lightbox-prev"
            onClick={(e) => { e.stopPropagation(); lightboxPrev() }}
            aria-label="Previous image"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6" /></svg>
          </button>

          <img
            src={ALL_IMAGES[lightboxIndex].full}
            alt={ALL_IMAGES[lightboxIndex].title}
            onClick={(e) => e.stopPropagation()}
          />

          <button
            type="button"
            className="modal-image-lightbox-nav modal-image-lightbox-next"
            onClick={(e) => { e.stopPropagation(); lightboxNext() }}
            aria-label="Next image"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6" /></svg>
          </button>
        </div>
      )}
    </section>
  )
})
