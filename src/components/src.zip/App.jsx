import { useEffect, useMemo, useRef, useState } from 'react'
import { BackgroundVideoProvider } from './components/BackgroundVideoManager.jsx'
import { SoundGateProvider } from './components/SoundGateProvider.jsx'
import { ProjectSection } from './components/ProjectSection.jsx'
import { DesignExamplesSection } from './components/DesignExamplesSection.jsx'
import { ProjectGrid } from './components/ProjectGrid.jsx'
import { ProjectModal } from './components/ProjectModal.jsx'
import { Nav } from './components/Nav.jsx'
import { Intro } from './components/Intro.jsx'
import { useSectionObserver } from './hooks/useSectionObserver.js'
import { useLenis, getLenis, setLenisSectionIndex } from './hooks/useLenis.js'
import { PROJECTS, ALL_PROJECTS, AMBIENT_BACKGROUND_VIDEOS } from './data/projects.js'

// Tracks a max-width media query live, including orientation changes
// (portrait <-> landscape), not just the width at first render.
function useMatchMedia(query) {
  const [matches, setMatches] = useState(
    () => typeof window !== 'undefined' && window.matchMedia(query).matches
  )
  useEffect(() => {
    const mql = window.matchMedia(query)
    const onChange = () => setMatches(mql.matches)
    onChange()
    mql.addEventListener('change', onChange)
    window.addEventListener('orientationchange', onChange)
    return () => {
      mql.removeEventListener('change', onChange)
      window.removeEventListener('orientationchange', onChange)
    }
  }, [query])
  return matches
}

function Experience() {
  useLenis()
  // Below 860px the layout stacks title/tablet/gallery/chips into one
  // column, which is frequently taller than a short mobile viewport
  // (especially landscape). A 0.55 intersection threshold could then
  // never be reached by any section, leaving activeIndex stuck at -1
  // forever (nothing shows, nothing plays). A lower threshold on small
  // viewports keeps sections switching active reliably, and also makes
  // the "leaving" transition less twitchy while scrolling on mobile.
  const isCompact = useMatchMedia('(max-width: 860px)')
  const { activeIndex, setRef } = useSectionObserver(PROJECTS.length, {
    threshold: isCompact ? 0.22 : 0.55,
  })
  const sectionRefs = useRef([])
  const [activeModalId, setActiveModalId] = useState(null)

  const jumpTo = (index) => {
    const el = document.getElementById(PROJECTS[index].id)
    if (!el) return
    const lenis = getLenis()
    if (lenis) {
      lenis.scrollTo(el, { duration: 1.1, easing: (t) => 1 - Math.pow(1 - t, 5) })
      // useLenis's internal section list is [intro, ...projects], so a
      // PROJECTS index of 0 is section index 1 there
      setLenisSectionIndex(index + 1)
    } else {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  // "All" nav item scrolls to the tile grid, which sits after the last
  // scroll section, not part of the per-project index/section list.
  const jumpToAll = () => {
    const el = document.getElementById('all-work')
    if (!el) return
    const lenis = getLenis()
    if (lenis) {
      lenis.scrollTo(el, { duration: 1.1, easing: (t) => 1 - Math.pow(1 - t, 5) })
    } else {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  // Opening the modal stops the main page's Lenis smoothing, so the
  // modal's own scroll (the browser's native overflow on the backdrop)
  // is the only thing scrolling, independent of the page behind it.
  const openModal = (id) => {
    getLenis()?.stop()
    setActiveModalId(id)
  }

  // Closing hands scrolling back to Lenis, then eases the page back to
  // the exact tile the project was opened from, rather than leaving the
  // view wherever it happened to land.
  const closeModal = () => {
    const returningToId = activeModalId
    setActiveModalId(null)

    const lenis = getLenis()
    lenis?.start()

    requestAnimationFrame(() => {
      const tile = document.getElementById(`tile-${returningToId}`)
      if (!tile) return
      if (lenis) {
        lenis.scrollTo(tile, {
          offset: -140,
          duration: 1.1,
          easing: (t) => 1 - Math.pow(1 - t, 5),
        })
      } else {
        tile.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }
    })
  }

  // Deep-linking: ?project=ID on load. Featured scroll projects take
  // priority (scrolls there); anything only in the bottom grid opens
  // its modal instead. Runs once on mount, after useLenis()'s own
  // effect above has already set up the shared Lenis instance, so
  // jumpTo/openModal's getLenis() calls resolve correctly straight away.
  useEffect(() => {
    const projectId = new URLSearchParams(window.location.search).get('project')
    if (!projectId) return

    const featuredIndex = PROJECTS.findIndex((p) => p.id === projectId)

    // one tick so layout (video aspect ratios, images) has settled
    // before scrollTo measures its target position
    requestAnimationFrame(() => {
      if (featuredIndex !== -1) {
        jumpTo(featuredIndex)
        return
      }
      if (ALL_PROJECTS.some((p) => p.id === projectId)) {
        openModal(projectId)
      }
    })
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <>
      <Nav projects={PROJECTS} activeIndex={activeIndex} onJump={jumpTo} onJumpAll={jumpToAll} />

      <Intro onEnter={() => jumpTo(0)} />

      <main>
        {PROJECTS.map((project, i) => {
          // Print & Editorial Design (id 18) has no video content, so it
          // recreates its own source-PDF composition instead of the
          // standard title/tablet layout — everything else about how
          // it's tracked (ref, index, observer) stays identical to
          // every other section.

          const SectionComponent = project.id === '18' ? DesignExamplesSection : ProjectSection
          return (
            <SectionComponent
              key={project.id}
              ref={(el) => {
                sectionRefs.current[i] = el
                setRef(i)(el)
              }}
              project={project}
              index={i}
              total={PROJECTS.length}
              isActive={i === activeIndex}
            />
          )
        })}
      </main>

      <ProjectGrid projects={ALL_PROJECTS} onOpen={openModal} />

      <ProjectModal
        projects={ALL_PROJECTS}
        activeId={activeModalId}
        onClose={closeModal}
        onNavigate={setActiveModalId}
      />

      <footer className="site-footer mono">
        <span>&copy; {new Date().getFullYear()} from the place</span>
      </footer>
    </>
  )
}

export default function App() {
  const projectCount = useMemo(() => PROJECTS.length, [])
  if (projectCount === 0) {
    return <p className="empty-state">No projects configured yet. Check src/data/rawProjectData.js.</p>
  }

  return (
    <SoundGateProvider>
      <BackgroundVideoProvider videoIds={AMBIENT_BACKGROUND_VIDEOS}>
        <Experience />
      </BackgroundVideoProvider>
    </SoundGateProvider>
  )
}
